<?php
if (!defined("ABSPATH")) {
    die("can't access");
}
ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);

global $wpdb;
$table_name = $wpdb->prefix . "epal_cost";
$result = $wpdb->get_results("SELECT * FROM $table_name LIMIT 1");
// check if data exists

$r = $result[0];
?>

<div>
    <div class="wrapper">
        <input type="checkbox" id="btn">
        <label for="btn" class="menu-btn">
            <i class="fas fa-bars"></i>
            <i class="fas fa-times"></i>
        </label>
        <nav id="sidebar">
            <div class="title">
                <a href="https://traffictail.com/"><img src="https://traffictail.com/wp-content/uploads/2022/10/tt-logo.png" width="150px" alt="">
                </a>
            </div>
            <ul class="list-items">
                <li><a href="#" data-target="#setup-details">Setup Details</a></li>
                <li><a href="#" id="ap" data-target="#apply"> Appliction</a></li>
                <li><a href="#" data-target="#shortcode">Shortcode</a></li>
                <li><a href="#" id="qr" data-target="#setting">Settings</a></li>

            </ul>
        </nav>
    </div>

    <div class="content">
        <div id="setup-details" class="section">
            <h1 class="text-center">Setup For Price </h1>
            <form method="POST" action="" class="container mt-3 ">
                <div class="row ">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="1m">1 Month Cost</label>
                            <input type="text" class="form-control" value="<?php echo $r->one_month; ?>" id="1m" name="one_month">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="website-1day">3 Month Cost</label>
                            <input type="text" class="form-control" value="<?php echo $r->three_month; ?>" id="3m" name="three_month" >
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="website-1day">6 Month Cost</label>
                            <input type="text" class="form-control" value="<?php echo $r->six_month; ?>" id="6m" name="six_month" placeholder="Enter number of views on Youtube">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="website-1week">1 Year Cost</label>
                            <input type="text" class="form-control" value="<?php echo $r->one_year; ?>" id="1y" name="one_year">
                        </div>
                    </div>
                </div>

                <button type="submit" name="dsubmit" class="btn btn-primary btn-lg btn-block">Submit</button>
            </form>
            <?php
            if(isset($_POST['dsubmit'])) {
                // Get form data
                $one_month = $_POST['one_month'];
                $three_month =$_POST['three_month'];
                $six_month =$_POST['six_month'];
                $one_year = $_POST['one_year'];
            
                // Insert data into database
                global $wpdb;
                $table_name = $wpdb->prefix . 'epal_cost';
                $wpdb->update($table_name,[
                    'one_month' => $one_month,
                    'three_month' => $three_month,
                    'six_month' => $six_month,
                    'one_year' => $one_year,
                ],["id" => 1]
            );
            
                echo "<script>location.reload();</script>";
            }
            
            ?>
        </div>
        <div id="apply" class="section">
            <?php

            function ep_custom_list_table()
            {
                global $wpdb;

                $table_name = $wpdb->prefix . 'epal_apply';

                if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
                    $id = $_GET['id'];
                    $wpdb->delete($table_name, array('id' => $id));
                }

                // Handle update request
                // Handle update request
                if (isset($_POST['usubmit'])) {
                    $id = $_POST['id'];
                    $status = $_POST['status'];
                    if ($status == 'rejected') {
                        $wpdb->delete($table_name, array('id' => $id));
                    } else {
                        $wpdb->update(
                            $table_name,
                            array('status' => $status),
                            array('id' => $id)
                        );
                    }
                    echo '<script>setTimeout(function() { document.querySelector("#ap").click(); }, 500);</script>';
                }
                $data = $wpdb->get_results("SELECT * FROM $table_name");

                echo '<table class="wp-list-table widefat fixed striped">';
                echo '<thead><tr><th>Package</th><th>Name</th><th>Date</th><th>Mobile</th><th>Paymnet Screenshot</th><th>Email</th> <th>Status</th></tr></thead>';
                echo '<tbody>';

                foreach ($data as $row) {
                    echo '<tr>';
                    echo '<td>';
                    if ($row->pkg == 'one_month') {
                        echo '1 month';
                    } elseif ($row->pkg == 'three_month') {
                        echo '3 months';
                    } elseif ($row->pkg == 'six_month') {
                        echo '6 months';
                    } elseif ($row->pkg == 'one_year') {
                        echo '1 year';
                    } else {
                        echo $row->pkg;
                    }
                    echo '</td>';
                    
                    echo '<td>' . $row->name . '</td>';
                    echo '<td>' . $row->date . '</td>';
                    echo '<td>' . $row->mobile . '</td>';
                    echo '<td><a href="' . wp_upload_dir()['url'] . '/' . basename($row->ps) . '" download>Download</a></td>';
                    echo '<td>' . $row->email . '</td>';
                    echo '<td> <form method="POST">';
                    echo '<select name="status"  style="width: 70px; text-overflow: ellipsis; white-space: nowrap; overflow: hidden;">';
                    echo '<option value="pending" ' . ($row->status == "pending" ? 'selected' : '') . '>Pending</option>';
                    echo '<option value="approved" ' . ($row->status == "approved" ? 'selected' : '') . '>Approved</option>';
                    echo '<option value="rejected" ' . ($row->status == "rejected" ? 'selected' : '') . '>Rejected</option>';
                    echo '</select>';
                    echo '<input type="hidden" name="id" value="' . $row->id . '">';
                    echo '<input type="submit" data-target="#ads-applied" class="ttup" name="usubmit" value="Update">';
                    echo '</form></td>';
                    echo '</tr>';
                }


                echo '</tbody>';
                echo '</table>';
            }

            add_shortcode('ep_custom_list_table', 'ep_custom_list_table');

            ep_custom_list_table();

            ?>
           
        </div>
        <div id="shortcode" class="section">
            <h5>Short code for form is [epalform]</h5>
        </div>
       
        <div id="setting" class="section">
            <form action="" class="mt-5" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="form-group col-md-12">
                        <label class="h6" for="name">Upload QR Image:</label>
                        <input type="file" accept=".jpg,.jpeg,.png" name="id_card_image" class="form-control" required>
                    </div>
                </div>
                <input type="submit" value="Upload" name="idimage" class="btn btn-success btn-lg btn-block my-3" id="">
            </form>

            <?php if (isset($_POST["idimage"])) {
                global $wpdb;
                $id_card_image = $_FILES["id_card_image"];

                $id_card_image_path = "";
                if ($id_card_image["name"]) {
                    $upload_dir = plugin_dir_path(__FILE__);
                    $id_card_image_name = basename($id_card_image["name"]);
                    $id_card_image_path =
                        $upload_dir . "/" . $id_card_image_name;
                    move_uploaded_file(
                        $id_card_image["tmp_name"],
                        $id_card_image_path
                    );
                }

                // inserting image
                $table_name = $wpdb->prefix . "my_ep_admin";
                $wpdb->insert($table_name, [
                    "id_card_image" => $id_card_image_name,
                ]);
                echo '<script>setTimeout(function() { document.querySelector("#qr").click(); }, 500);</script>';
            } ?>
            <div class="idcard" style="margin-top: 30px;">
                <?php
                echo "<h4>Current image for QR</h4>";
                global $wpdb;
                // Get the ID card image from the database
                $table_name8 = $wpdb->prefix . "my_ads_admin"; // add prefix to table name
                $sql1 = "SELECT id_card_image FROM $table_name8 ORDER BY id DESC LIMIT 1"; // get the last row ordered by ID in descending order and limit the result to 1 row
                $result2 = $wpdb->get_results($sql1, ARRAY_A); // use get_results to get data as associative array
                if (!empty($result2)) {
                    $row2 = $result2[0]; // get first row from resultset
                    $id_card_image = $row2["id_card_image"];
                    echo '<img src="' .
                        plugin_dir_url(__FILE__) .
                        $id_card_image .
                        '"  width="500px">';
                } else {
                    echo "Please Upload image";
                }
                ?>
            </div>

        </div>
    </div>
</div>