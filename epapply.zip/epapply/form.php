<?php
if (!defined("ABSPATH")) {
    die("can't access");
}
require_once(ABSPATH . 'wp-includes/pluggable.php');

add_shortcode("epalform", "epalform_form_func");
function epalform_form_func()
{
    ob_start();

?>

   <div>
   <div id="costdata" style="display: none;">
        <?php
        global $wpdb;
        $table_name2 = $wpdb->prefix . 'epal_cost';

        // Fetch the row with ID 1
        $result = $wpdb->get_row("SELECT * FROM $table_name2 WHERE id = 1");

        // If a row was found, display the data in the div tags
        if ($result) {
        ?>
            <div id="c1"><?php echo $result->one_month; ?></div>
            <div id="c2"><?php echo $result->three_month; ?></div>
            <div id="c3"><?php echo $result->six_month; ?></div>
            <div id="c4"><?php echo $result->one_year; ?></div>

        <?php
        } else {
            echo 'No data found';
        }
        ?>

    </div>
    <div>

        <?php
        // Check if alert message is set and display it
        if (isset($_SESSION['alert_message'])) {
            echo "<b class='text-success'>" . $_SESSION['alert_message'] . "</b>";
            // Unset the session variable to prevent it from being displayed again on subsequent page loads
            unset($_SESSION['alert_message']);
        }
        if (isset($_SESSION['m_alert_message'])) {
            echo "<b class='text-danger'>" . $_SESSION['m_alert_message'] . "</b>";
            // Unset the session variable to prevent it from being displayed again on subsequent page loads
            unset($_SESSION['m_alert_message']);
        }
        ?>
        <form method="POST" action="" enctype="multipart/form-data">
            <div class="form-group row">
                <div class="col-md-6">
                    <label>Package </label>
                    <select class="form-control" name="pkg" id="pkg" onchange="updatecost()" required>
                        <option value="">--Select--</option>
                        <option value="one_month">1 Month</option>
                        <option value="three_month">3 Months</option>
                        <option value="six_month">6 Months</option>
                        <option value="one_year">1 Year</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="price">Price:</label>
                    <input type="text" class="form-control" id="price" name="price" disabled>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label for="place">Name:</label>
                    <input type="text" class="form-control" id="place" name="name">
                </div>
                <div class="col-md-6">
                    <label for="date">Date:</label>
                    <input type="date" class="form-control" id="date" name="date">
                </div>
            </div>
            <div class="form-group row">

                <div class="col-md-6">
                    <label for="mobile">Mobile:</label>
                    <input type="tel" class="form-control" id="mobile" name="mobile" required>
                </div>
                <div class="col-md-6">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-2 mt-4">
                    <?php
                    $n1 = rand(1, 20);
                    $n2 = rand(1, 20);
                    $sum = $n1 + $n2;
                    echo $n1 . "+" . $n2 . "=";
                    ?>
                </div>
                <div class="col-md-4 mt-4">
                    <input type="number" name="sum">
                    <input type="hidden" value="<?php echo  $sum ?>" name="sum2">
                </div>
                <div class="col-md-12">
                    <?php
                    echo "<h4>image for QR Payment</h4>";
                    global $wpdb;
                    // Get the ID card image from the database
                    $table_name8 = $wpdb->prefix . "my_ep_admin"; // add prefix to table name
                    $sql1 = "SELECT id_card_image FROM $table_name8 ORDER BY id DESC LIMIT 1"; // get the last row ordered by ID in descending order and limit the result to 1 row
                    $result2 = $wpdb->get_results($sql1, ARRAY_A); // use get_results to get data as associative array
                    if (!empty($result2)) {
                        $row2 = $result2[0]; // get first row from resultset
                        $id_card_image = $row2["id_card_image"];
                        echo '<img src="' . plugin_dir_url(__FILE__) . $id_card_image . '"  width="500px">';
                    }
                    ?>
                </div>
                <div class="col-md-6">
                    <label for="image">Payment Screenshot:</label>
                    <input type="file" class="form-control" id="ps" name="ps" required>
                </div>
            </div>
            <input type="submit" class="btn btn-lg btn-block mt-3" name="epalsubmit" value="Submit">

        </form>

    </div>
   </div>
<?php

    return ob_get_clean();
}
if (isset($_POST["epalsubmit"])) {
    if ($_POST["sum"] !== $_POST["sum2"]) {
        echo "<script>alert('The answer to the math question is incorrect.')</script>";
    } else {
        global $wpdb;
        $table_name = $wpdb->prefix . 'epal_apply';

        $pkg = sanitize_text_field($_POST['pkg']);
        $name = sanitize_text_field($_POST['name']);
        $date = sanitize_text_field($_POST['date']);
        $mobile = sanitize_text_field($_POST['mobile']);
        $email = sanitize_email($_POST['email']);

        $existing_email = $wpdb->get_var($wpdb->prepare("SELECT email FROM $table_name WHERE email = %s AND status = 'pending'", $email));
        if ($existing_email) {
            echo "<script>alert('Your request is in pending')</script>";
        } else {

            $ps = $_FILES['ps'];
            // Upload  picture
            $ps_path = '';
            if ($ps['name']) {
                $upload_dir = wp_upload_dir();
                $ps_name = basename($ps['name']);
                $ps_path = $upload_dir['path'] . '/' . $ps_name;
                move_uploaded_file($ps['tmp_name'], $ps_path);
            }

            $status = 'pending';

            $data = array(
                'pkg' => $pkg,
                'name' => $name,
                'date' => $date,
                'mobile' => $mobile,
                'email' => $email,
                'ps' => $ps_path,
                'status' => $status,
            );

            $result = $wpdb->insert($table_name, $data);
            if ($result === false) {
                wp_die('Failed to insert data into database: ' . $wpdb->last_error);
            } else {
                echo '<script>alert("Data inserted successfully!"); window.location.href = "' . $current_url . '";</script>';
                //     $current_url = esc_url_raw($_SERVER['REQUEST_URI']);
                // wp_safe_redirect($current_url);
                // exit;
            }
        }
    }
}

?>