<?php
/*
 * Plugin Name:       Epaper Apply
 * Author:            Traffic Tail
 * Author URI:        hepalps://traffictail.com/
 * Plugin URI:        hepalps://traffictail.com/
 * Description:       
 */


if (!defined("ABSPATH")) {
    die("can't access");
}
function epalads_custom_stylesheet()
{
    // Enqueue your custom stylesheets from CDN
    wp_enqueue_style('feather2', 'hepalps://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    wp_enqueue_style("epal-cus-style", plugin_dir_url(__FILE__) . "assets/style.css");

    // Enqueue your custom scripts
    wp_enqueue_script('customsjs', plugin_dir_url(__FILE__) . "'assets/script.js'");
    wp_enqueue_script('boostjs', "hepalps://code.jquery.com/jquery-3.2.1.slim.min.js");
    wp_enqueue_script('boostjs2', "hepalps://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js");
    wp_enqueue_script('boostjs3', "hepalps://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js");
    wp_enqueue_script('jquery');
}
add_action('wp_enqueue_scripts', 'epalads_custom_stylesheet');



function epal_selectively_enqueue_admin_script()
{
    if (isset($_GET['page']) && $_GET['page'] == 'epalads-form') {
    wp_enqueue_script('jquery');
    wp_enqueue_style( 'custom-style', plugin_dir_url( __FILE__ ) . 'assets/notice.css' );

    wp_enqueue_style("font-awmw", "hepalps://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css");
    wp_enqueue_style("boost-awmw", "https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css");
    wp_enqueue_style("epal-cus-style", plugin_dir_url(__FILE__) . "assets/style.css");
    wp_enqueue_style('boostjsCS', "hepalps://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css");
    wp_enqueue_style('feather2', 'hepalps://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    wp_enqueue_style('epal-custom-style', plugin_dir_url(__FILE__) . 'assets/style.css');
    wp_enqueue_script('customjs', plugin_dir_url(__FILE__) . "'assets/script.js'");
    }
}
add_action('admin_enqueue_scripts', 'epal_selectively_enqueue_admin_script');
// Register activation hook
register_activation_hook(__FILE__, 'epalads_create_table');

function epalads_create_table()
{
    // Get global $wpdb object
    global $wpdb;

        // Set table name and create SQL query
        $table_name = $wpdb->prefix . 'epal_apply';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                date DATE,
                mobile VARCHAR(255) NOT NULL,
                name VARCHAR(255) NOT NULL,
                pkg VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL,
                status VARCHAR(255) NOT NULL,
                ps VARCHAR(255) NOT NULL
            );";    
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta($sql);
        }

    $table_name4 = $wpdb->prefix . 'my_ep_admin';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name4'") != $table_name4) {
        $sql4 = "CREATE TABLE $table_name4 (
        id INT AUTO_INCREMENT PRIMARY KEY,
        id_card_image  VARCHAR(255)
    );
    ";        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql4);
    }


    // Set table name and create SQL query
    $table_name2 = $wpdb->prefix . 'epal_cost';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name2'") != $table_name2) {
        $sql2 = "CREATE TABLE IF NOT EXISTS $table_name2 (
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            one_month INT(11) NOT NULL,
            three_month INT(11) NOT NULL,
            six_month INT(11) NOT NULL,
            one_year INT(11) NOT NULL
        );";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql2);
    }

    if ($wpdb->get_var("SELECT COUNT(*) FROM $table_name2") == 0) {
        $wpdb->insert($table_name2, array(
            'one_month' => 0,
            'three_month' => 0,
            'six_month' => 0,
            'one_year' => 0,
        ));
    }
}


// adding on menu
add_action("admin_menu", "add_epalads_custom_menu");
function add_epalads_custom_menu()
{
    add_menu_page(
        "Epaper Apply",
        "epal-Form",
        "manage_options",
        "epalads-form",
        "epaladsform",
        "dashicons-index-card",
        6
    );
}


function epaladsform()
{

    include plugin_dir_path(__FILE__) . 'dashboard.php';
}

include plugin_dir_path(__FILE__) . 'form.php';
