jQuery(document).ready(function () {
  jQuery(".section").hide(); // Hide all sections initially
  jQuery("#setup-details").show(); // Show the initial section

  // Handle clicks on the menu items
  jQuery(".list-items li a").click(function (e) {
    e.preventDefault();
    jQuery(".section").hide(); // Hide all sections
    var target = jQuery(this).data("target"); // Get the target section ID
    jQuery(target).show(); // Show the target section
  });
});


function updatecost() {
  const dropdownElement = document.getElementById("pkg");
  const selectedOption = dropdownElement.value;
  const price =document.getElementById("price");
  const wtp1w = parseFloat(document.getElementById("c1").textContent);
  const wtp1m = parseFloat(document.getElementById("c2").textContent);
  const wtp1y = parseFloat(document.getElementById("c3").textContent);
  const wtp11y = parseFloat(document.getElementById("c4").textContent);

  let cost = 0;

  if (selectedOption === "one_month") {
    price.value = wtp1w;
  } else if (selectedOption === "three_month") {
    price.value = wtp1m;
  } else if (selectedOption === "six_month") {
    price.value = wtp1y;
  } else if (selectedOption === "one_year") {
    price.value = wtp11y;
  }else{
    price.value="";
  }

 
}