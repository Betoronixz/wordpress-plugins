<?php

// if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
//     die;
// }

// global $wpdb;
// $table_name = $wpdb->prefix . 'news_user';
// $table_name2 = $wpdb->prefix . 'my_news_admin';

// $sql = "DROP TABLE IF EXISTS $table_name";
// $wpdb->query($sql);

// $sql2 = "DROP TABLE IF EXISTS $table_name2";
// $wpdb->query($sql2);