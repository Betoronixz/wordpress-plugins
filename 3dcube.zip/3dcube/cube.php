<div class="cube-container">
    <div class="icon" onclick="CloseCube()"><i class="fa-solid fa-circle-xmark"></i></div>
    <div class="cube">
        <div class="front">
            <div class="time">
                <?php
                date_default_timezone_set('Asia/Kolkata');
                $t = time();
                echo (date("Y-m-d", $t));
                ?>
            </div>
        </div>
        <div class="back">
            <div class="time">
                <?php
                $custom_logo_id = get_theme_mod('custom_logo');
                $logo_url = wp_get_attachment_image_src($custom_logo_id, 'full');
                if ($logo_url) {
                    echo '<img src="' . esc_url($logo_url[0]) . '" width="100px" alt="Site Logo">';
                }
                ?>
            </div>
        </div>
        <div class="top">
            <div class="time">

            </div>
        </div>
        <div class="bottom">
            <div class="time">Current Time</div>
        </div>
        <div class="right">
            <div class="time">
                <?php
                date_default_timezone_set('Asia/Kolkata');
                echo  date("h:i:sa");
                ?>
            </div>
        </div>
        <div class="left">
            <div class="time"><img src="<?php echo plugin_dir_url(__FILE__) . "live.webp" ?>" width="100px" alt=""></div>
        </div>
    </div>
</div>