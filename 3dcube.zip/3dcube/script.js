function CloseCube() {
    var elements = document.getElementsByClassName("cube-container");
    if (elements.length > 0) {
      elements[0].style.display = "none";
    }
  }
  