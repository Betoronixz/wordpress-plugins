<?php
/*
Plugin Name: TT 3D Cube


*/

add_action("wp_enqueue_scripts", "tt_3d_css");
function tt_3d_css(){
    wp_enqueue_style("3dstyle", plugin_dir_url(__FILE__)."style.css");
    wp_enqueue_style("fs","https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css");
    wp_enqueue_script("3dscript", plugin_dir_url(__FILE__)."script.js");
    wp_enqueue_script('jquery');
    
}

add_action('wp_footer', 'include_cube_file');
function include_cube_file() {
    include_once(plugin_dir_path(__FILE__) . 'cube.php');
}
