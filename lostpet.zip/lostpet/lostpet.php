<?php
/*
 * Plugin Name:       Lost Pet Report
 * Author:            Traffic Tail
 * Author URI:        https://traffictail.com/
 * Plugin URI:        https://traffictail.com/
 * Description:       The "Lost Pet Report" plugin is a powerful and user-friendly WordPress plugin that allows pet owners to easily create and submit reports for lost pets through a customizable form. The plugin provides a seamless way for pet owners to report their lost pets, providing essential details such as pet's color, breed, date lost, location, and contact information.

 */


 if (!defined("ABSPATH")) {
    die("can't access");
}
// Including stylesheet and javascript
function lf_custom_stylesheet() {
    // Enqueue your custom stylesheets from CDN
    wp_enqueue_style( 'feather', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css' );
    wp_enqueue_style( 'owlcdn', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css' );
    wp_enqueue_style( 'owlcdnc', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css' );
    wp_enqueue_style( 'custom-style', plugin_dir_url(__FILE__).'assets/style.css' );

    // Enqueue your custom scripts
    wp_enqueue_script('jquery');
    wp_enqueue_script( 'canvas', "https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js");
    wp_enqueue_script( 'customjs', plugin_dir_url(__FILE__)."'assets/script.js'");
}
add_action( 'wp_enqueue_scripts', 'lf_custom_stylesheet' );




// Register activation hook
register_activation_hook(__FILE__, 'lf_create_table');

function lf_create_table()
{
    // Get global $wpdb object
    global $wpdb;

    // Set table name and create SQL query
    $table_name = $wpdb->prefix .'lost_found';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $sql = "CREATE TABLE IF NOT EXISTS $table_name(
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            color VARCHAR(255) NOT NULL,
            breed VARCHAR(255) NOT NULL,
            date DATE,
            place VARCHAR(255),
            address VARCHAR(255) NOT NULL,
            nameOfApplicant VARCHAR(255) NOT NULL,
            lf VARCHAR(255) NOT NULL,
            mobile VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            location VARCHAR(255) NOT NULL,
            photo VARCHAR(255) NOT NULL,
            ps VARCHAR(255) NOT NULL,
            otherDetails TEXT
          );
          
        ";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }
    
    // Execute query and check for errors
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

   
}
// adding on menu
add_action("admin_menu", "add_lf_custom_menu");
function add_lf_custom_menu()
{
    add_menu_page(
        "Shortcode",
        "Lost pet",
        "manage_options",
        "lf-form",
        "lfform",
        "dashicons-index-card",
        6
    );
   
}
function lfform(){
   
    echo "Short code for form is  [lost_found_pet]";
   
}


include plugin_dir_path(__FILE__) . 'form.php';


?>
