<?php add_shortcode('lost_found_pet', 'lost_found_pet_form');
function lost_found_pet_form()
{
    ob_start();

?>

    <div class="row mb-5 text-center">
        <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" value="f" onclick="foundAnimal()">
            <label class="form-check-label" for="flexRadioDefault1">
                Found Animal
            </label>
        </div>
        <div class="form-check mx-3">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" value="f" checked onclick="lostAnimal()">
            <label class="form-check-label" for="flexRadioDefault2">
                Lost Animal
            </label>
        </div>
    </div>
    <div class="lost">
        <h2>Lost Pet</h2>
        <form method="post" action="" enctype="multipart/form-data">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Color</label>
                        <input placeholder="Color" type="text" id="reservation_name" name="color" required="" class="form-control">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Breed</label>
                        <input placeholder="Breed" type="text" id="reservation_email" name="breed" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Date</label>
                        <input name="date" class="form-control required date-picker" type="text" placeholder="Date" aria-required="true">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Place</label>
                        <input name="place" class="form-control" type="text" placeholder="Place" aria-required="true">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Address</label>
                        <input placeholder="Address" type="text" id="reservation_email" name="address" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Name Of Applicant</label>
                        <input placeholder="Name Of Applicant" type="text" id="reservation_email" name="nameOfApplicant" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Mobile No.</label>
                        <input placeholder="Mobile No." type="text" id="reservation_email" name="mobile" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Email</label>
                        <input placeholder="Email" type="email" id="reservation_email" name="email" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Location</label>
                        <input placeholder="Location" type="text" id="training_period" name="location" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Photo</label>
                        <input placeholder="Photo" accept=".jpeg, .jpg, .png, .webp" type="file" id="fee" name="photo" class="form-control" required="">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Police Station</label>
                        <input placeholder="Photo" accept=".jpeg, .jpg, .png, .webp" type="file" id="fee" name="ps" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-12">
                    <div class="form-group mb-30">
                        <label>Other Details</label>
                        <textarea placeholder="strap color etc." id="fee" name="otherDetails" class="form-control" required="" row="6"></textarea>
                    </div>
                </div>


                <div class="col-sm-12">
                    <div class="form-group text-center mb-0 mt-20">
                        <button type="submit" name="lost" class="" id="submitBtn" <?php if (isset($_SESSION["isFormSubmitted"]) && $_SESSION["isFormSubmitted"]) echo "disabled";
                                                                                    else echo "onclick=\"setTimeout(enableSubmitButton, 60000)\""; ?>>Report</button>
                    </div>
                </div>
            </div>
        </form>
        <div class="home-demo">
            <h3>Lost Pet</h3>
            <div class="owl-carousel owl-theme">
                <?php
                global $wpdb;
                $table_name = $wpdb->prefix . "lost_found";
                $result = $wpdb->get_results("SELECT * FROM $table_name WHERE lf = 'lost'");
                if (!empty($result)) {
                    foreach ($result as $r) {
                ?>
                        <div class="item">

                            <img src="<?php echo wp_upload_dir()['url'] . '/' . basename($r->photo) ?>" alt="">
                            <?php echo "    <h3 class='text-center'>$r->breed</h3>      "; ?>
                            <?php echo "    <p class='text-center'>$r->otherDetails</p>      "; ?>

                        </div>
                <?php  }
                } ?>
            </div>
        </div>
    </div>
    <div class="found">
        <h2>Found Pet</h2>
        <form method="post" action="" enctype="multipart/form-data">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Color</label>
                        <input placeholder="Color" type="text" id="reservation_name" name="color" required="" class="form-control">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Breed</label>
                        <input placeholder="Breed" type="text" id="reservation_email" name="breed" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Date</label>
                        <input name="date" class="form-control required date-picker" type="text" placeholder="Date" aria-required="true">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Place</label>
                        <input name="place" class="form-control" type="text" placeholder="Place" aria-required="true">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Address</label>
                        <input placeholder="Address" type="text" id="reservation_email" name="address" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Name Of Applicant</label>
                        <input placeholder="Name Of Applicant" type="text" id="reservation_email" name="nameOfApplicant" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Mobile No.</label>
                        <input placeholder="Mobile No." type="text" id="reservation_email" name="mobile" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Email</label>
                        <input placeholder="Email" type="email" id="reservation_email" name="email" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Location</label>
                        <input placeholder="Location" type="text" id="training_period" name="location" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Photo</label>
                        <input placeholder="Photo" accept=".jpeg, .jpg, .png, .webp" type="file" id="fee" name="photo" class="form-control" required="">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group mb-30">
                        <label>Police Station</label>
                        <input placeholder="Photo" accept=".jpeg, .jpg, .png, .webp" type="file" id="fee" name="ps" class="form-control" required="">
                    </div>
                </div>

                <div class="col-sm-12">
                    <div class="form-group mb-30">
                        <label>Other Details</label>
                        <textarea placeholder="strap color etc." id="fee" name="otherDetails" class="form-control" required="" row="6"></textarea>
                    </div>
                </div>


                <div class="col-sm-12">
                    <div class="form-group text-center mb-0 mt-20">
                        <button type="submit" name="found" class="" id="submitBtn" <?php if (isset($_SESSION["isFormSubmitted"]) && $_SESSION["isFormSubmitted"]) echo "disabled";
                                                                                    else echo "onclick=\"setTimeout(enableSubmitButton, 60000)\""; ?>>Report</button>
                    </div>
                </div>
            </div>
        </form>
        <div class="home-demo">
            <h3>Found Pet</h3>
            <div class="owl-carousel owl-theme">
                <?php
                global $wpdb;
                $table_name = $wpdb->prefix . "lost_found";
                $result = $wpdb->get_results("SELECT * FROM $table_name WHERE lf = 'found'");
                if (!empty($result)) {
                    foreach ($result as $r) {
                ?>
                        <div class="item">

                            <img src="<?php echo wp_upload_dir()['url'] . '/' . basename($r->photo) ?>" alt="">
                            <?php echo "    <h3 class='text-center'>$r->breed</h3>      "; ?>
                            <?php echo "    <p class='text-center'>$r->otherDetails</p>      "; ?>

                        </div>
                <?php  }
                } ?>
            </div>
        </div>
    </div>





<?php
    return ob_get_clean();
}
if (isset($_POST["found"])) {
    session_start();
    // Get the current timestamp
    $currentTime = time();
    if (!isset($_SESSION["lastFormSubmitTime"]) || ($currentTime - $_SESSION["lastFormSubmitTime"]) >= 120) {
        global $wpdb;

        // Get form data from POST request
        // Sanitize input data
        $color = sanitize_text_field($_POST['color']);
        $breed = sanitize_text_field($_POST['breed']);
        $date = sanitize_text_field($_POST['date']);
        $place = sanitize_text_field($_POST['place']);
        $address = sanitize_text_field($_POST['address']);
        $nameOfApplicant = sanitize_text_field($_POST['nameOfApplicant']);
        $mobile = sanitize_text_field($_POST['mobile']);
        $email = sanitize_email($_POST['email']);
        $location = sanitize_text_field($_POST['location']);
        $otherDetails = sanitize_textarea_field($_POST['otherDetails']);

        // Sanitize uploaded file
        $photo = $_FILES['photo'];
        $ps = $_FILES['ps'];

        if (function_exists('wp_handle_upload')) {
            $uploaded_file = wp_handle_upload($photo, array('test_form' => false));
            if (isset($uploaded_file['file'])) {
                $photo = $uploaded_file['file'];
            } else {
                $photo = ''; // Set to empty string if file upload fails
            }
        }
        if (function_exists('wp_handle_upload')) {
            $uploaded_file = wp_handle_upload($ps, array('test_form' => false));
            if (isset($uploaded_file['file'])) {
                $ps = $uploaded_file['file'];
            } else {
                $ps = ''; // Set to empty string if file upload fails
            }
        }


        $photo_path = '';
        if ($photo['name']) {
            $upload_dir = wp_upload_dir();
            $photo_name = basename($photo['name']);
            $photo_path = $upload_dir['path'] . '/' . $photo_name;
            move_uploaded_file($photo['tmp_name'], $photo_path);
        }
        $ps_path = '';
        if ($ps['name']) {
            $upload_dir = wp_upload_dir();
            $ps_name = basename($ps['name']);
            $ps_path = $upload_dir['path'] . '/' . $ps_name;
            move_uploaded_file($ps['tmp_name'], $ps_path);
        }

        // Prepare data for insertion
        $data = array(
            'color' => $color,
            'breed' => $breed,
            'date' => $date,
            'place' => $place,
            'address' => $address,
            'nameOfApplicant' => $nameOfApplicant,
            'mobile' => $mobile,
            'email' => $email,
            'location' => $location,
            'photo' => $photo_path,
            'ps' => $ps_path,
            'otherDetails' => $otherDetails,
            'lf' => "found"
        );

        // Insert data into database
        $table_name = $wpdb->prefix . 'lost_found';
        $result = $wpdb->insert($table_name, $data);

        if ($result) {
            // Success! Redirect or display success message
            echo "<script>alert('Data inserted ')</script>";
            $_SESSION["isFormSubmitted"] = true;
            $_SESSION["lastFormSubmitTime"] = $currentTime;
        } else {
            // Error! Display error message
            echo "Error inserting data: " . $wpdb->last_error;
        }
    }
}
if (isset($_POST["lost"])) {
    session_start();
    // Get the current timestamp
    $currentTime = time();
    if (!isset($_SESSION["lastFormSubmitTime"]) || ($currentTime - $_SESSION["lastFormSubmitTime"]) >= 120) {
        global $wpdb;

        // Get form data from POST request
        // Sanitize input data
        $color = sanitize_text_field($_POST['color']);
        $breed = sanitize_text_field($_POST['breed']);
        $date = sanitize_text_field($_POST['date']);
        $place = sanitize_text_field($_POST['place']);
        $address = sanitize_text_field($_POST['address']);
        $nameOfApplicant = sanitize_text_field($_POST['nameOfApplicant']);
        $mobile = sanitize_text_field($_POST['mobile']);
        $email = sanitize_email($_POST['email']);
        $location = sanitize_text_field($_POST['location']);
        $otherDetails = sanitize_textarea_field($_POST['otherDetails']);

          // Sanitize uploaded file
          $photo = $_FILES['photo'];
          $ps = $_FILES['ps'];
  
          if (function_exists('wp_handle_upload')) {
              $uploaded_file = wp_handle_upload($photo, array('test_form' => false));
              if (isset($uploaded_file['file'])) {
                  $photo = $uploaded_file['file'];
              } else {
                  $photo = ''; // Set to empty string if file upload fails
              }
          }
          if (function_exists('wp_handle_upload')) {
              $uploaded_file = wp_handle_upload($ps, array('test_form' => false));
              if (isset($uploaded_file['file'])) {
                  $ps = $uploaded_file['file'];
              } else {
                  $ps = ''; // Set to empty string if file upload fails
              }
          }
  
  
          $photo_path = '';
          if ($photo['name']) {
              $upload_dir = wp_upload_dir();
              $photo_name = basename($photo['name']);
              $photo_path = $upload_dir['path'] . '/' . $photo_name;
              move_uploaded_file($photo['tmp_name'], $photo_path);
          }
          $ps_path = '';
          if ($ps['name']) {
              $upload_dir = wp_upload_dir();
              $ps_name = basename($ps['name']);
              $ps_path = $upload_dir['path'] . '/' . $ps_name;
              move_uploaded_file($ps['tmp_name'], $ps_path);
          }
  

        // Prepare data for insertion
        $data = array(
            'color' => $color,
            'breed' => $breed,
            'date' => $date,
            'place' => $place,
            'address' => $address,
            'nameOfApplicant' => $nameOfApplicant,
            'mobile' => $mobile,
            'email' => $email,
            'location' => $location,
            'photo' => $photo_path,
            'ps' => $ps_path,
            'otherDetails' => $otherDetails,
            'lf' => "lost"
        );

        // Insert data into database
        $table_name = $wpdb->prefix . 'lost_found';
        $result = $wpdb->insert($table_name, $data);

        if ($result) {
            // Success! Redirect or display success message
            echo "<script>alert('Data inserted ')</script>";
            $_SESSION["isFormSubmitted"] = true;
            $_SESSION["lastFormSubmitTime"] = $currentTime;
        } else {
            // Error! Display error message
            echo "Error inserting data: " . $wpdb->last_error;
        }
    }
}
?>