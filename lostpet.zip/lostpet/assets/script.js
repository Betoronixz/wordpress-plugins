jQuery(document).ready(function ($) {
    $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        responsiveClass: true,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: false,
        responsive: {
            0: {
                items: 1,
                nav: true
            },
            600: {
                items: 2,
                nav: false
            },
            1000: {
                items: 3,
                nav: true,
                loop: false
            }
        }
    });
});


function foundAnimal() {
    var lostElements = document.getElementsByClassName("lost");
    var foundElements = document.getElementsByClassName("found");
  
    for (var i = 0; i < lostElements.length; i++) {
      lostElements[i].style.display = "none";
    }
  
    for (var j = 0; j < foundElements.length; j++) {
      foundElements[j].style.display = "block";
    }
  }
  
  function lostAnimal() {
    var lostElements = document.getElementsByClassName("lost");
    var foundElements = document.getElementsByClassName("found");
  
    for (var i = 0; i < lostElements.length; i++) {
      lostElements[i].style.display = "block";
    }
  
    for (var j = 0; j < foundElements.length; j++) {
      foundElements[j].style.display = "none";
    }
  }
  