jQuery(document).ready(function () {
    jQuery('#example').DataTable();
});