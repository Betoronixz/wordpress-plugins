<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-body bg-info">Admin Panel</div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">Users</div>
            <div class="panel-body">
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Resume</th>
                            <th>Experience letter from back home </th>
                            <th>Salary Slips</th>
                            <th>Covid Vaccine Certificate</th>
                            <th>ITR / bank statement (Showing Salary)</th>
                            <th>TRF copy (Only If you have IELTS)</th>
                            <th>Any Certification in Canada (if available)</th>
                            <th>Educational Documents</th>
                            <th>Medical Test by Panel Physicians</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        global $wpdb;
                        $table_name = $wpdb->prefix . "docro_user_table";
                        $result = $wpdb->get_results("SELECT * FROM $table_name");
                        if (!empty($result)) {
                            foreach ($result as $r) {
                        ?>
                                <tr>
                                    <td><?php echo $r->id ?></td>
                                    <td><?php echo $r->name ?></td>
                                    <td><?php echo $r->email ?></td>
                                    <td><?php echo $r->phone ?></td>
                                    <td>
                                        <?php
                                        $resume_path = wp_upload_dir()['baseurl'] . "/" . $r->resume;
                                        if (!is_null($r->resume) && !empty($r->resume)) {
                                            echo '<a href="' . $resume_path . '" download>Download </a>';
                                        } else {
                                            echo 'No file uploaded';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $experience_letter_path = wp_upload_dir()['baseurl'] . "/" . $r->experience_letter;
                                        if (!is_null($r->experience_letter) && !empty($r->experience_letter)) {
                                            echo '<a href="' . $experience_letter_path . '" download>Download </a>';
                                        } else {
                                            echo 'No file uploaded';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $salary_slip_path = wp_upload_dir()['baseurl'] . "/" . $r->salary_slip;
                                        if (!is_null($r->salary_slip) && !empty($r->salary_slip)) {
                                            echo '<a href="' . $salary_slip_path . '" download>Download </a>';
                                        } else {
                                            echo 'No file uploaded';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $covid_vaccine_certificate_path = wp_upload_dir()['baseurl'] . "/" . $r->covid_vaccine_certificate;
                                        if (!is_null($r->covid_vaccine_certificate) && !empty($r->covid_vaccine_certificate)) {
                                            echo '<a href="' . $covid_vaccine_certificate_path . '" download>Download </a>';
                                        } else {
                                            echo 'No file uploaded';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $canada_certification_path = wp_upload_dir()['baseurl'] . "/" . $r->canada_certification;
                                        if (!is_null($r->canada_certification) && !empty($R->canada_certification)) {
                                            echo '<a href="' . $canada_certification_path . '" download>Download </a>';
                                        } else {
                                            echo 'No file uploaded';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $itr_bank_statement_path = wp_upload_dir()['baseurl'] . "/" . $r->itr_bank_statement;
                                        if (!is_null($r->itr_bank_statement) && !empty($r->itr_bank_statement)) {
                                            echo '<a href="' . $itr_bank_statement_path . '" download>Download </a>';
                                        } else {
                                            echo 'No file uploaded';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $ielts_trf_copy_path = wp_upload_dir()['baseurl'] . "/" . $r->ielts_trf_copy;
                                        if (!is_null($r->ielts_trf_copy) && !empty($r->ielts_trf_copy)) {
                                            echo '<a href="' . $ielts_trf_copy_path . '" download>Download </a>';
                                        } else {
                                            echo 'No file uploaded';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $educational_documents_path = wp_upload_dir()['baseurl'] . "/" . $r->educational_documents;
                                        if (!is_null($r->educational_documents) && !empty($r->educational_documents)) {
                                            echo '<a href="' . $educational_documents_path . '" download>Download </a>';
                                        } else {
                                            echo 'No file uploaded';
                                        }

                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $medical_test_path = wp_upload_dir()['baseurl'] . "/" . $r->medical_test;
                                        if (!is_null($r->medical_test)  && !empty($r->medical_test)) {
                                            echo '<a href="' . $medical_test_path . '" download>Download </a>';
                                        } else {
                                            echo 'No file uploaded';
                                        }
                                        ?>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Resume</th>
                            <th>Experience letter from back home </th>
                            <th>Salary Slips</th>
                            <th>Covid Vaccine Certificate</th>
                            <th>ITR / bank statement (Showing Salary)</th>
                            <th>TRF copy (Only If you have IELTS)</th>
                            <th>Any Certification in Canada (if available)</th>
                            <th>Educational Documents</th>
                            <th>Medical Test by Panel Physicians</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

    </div>
</div>