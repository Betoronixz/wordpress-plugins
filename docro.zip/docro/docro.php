<?php
/*
* Plugin Name:       docro  
*/


//  include css and js
if (!defined("MY_DOC_PLUGIN_PATH")) {
    define("MY_DOC_PLUGIN_PATH", plugin_dir_path(__FILE__));
}

if (!defined("MY_DOC_PLUGIN_URL")) {
    define("MY_DOC_PLUGIN_URL", plugin_dir_url(__FILE__));
}
function my_DOC_include_assets()
{
    //styles
    wp_enqueue_style("bootstrap", MY_DOC_PLUGIN_URL . "/assets/css/bootstrap.min.css", '');
    wp_enqueue_style("bootstrap2", MY_DOC_PLUGIN_URL . "/assets/css/2bootstrap.min.css", '');
    wp_enqueue_style("datatable", MY_DOC_PLUGIN_URL . "/assets/css/jquery.dataTables.min.css", '');
    wp_enqueue_style("notifybar", MY_DOC_PLUGIN_URL . "/assets/css/jquery.notifyBar.css", '');
    //scripts
    wp_enqueue_script('jquery');
    wp_enqueue_script('bootstrap.min.js', MY_DOC_PLUGIN_URL . '/assets/js/bootstrap.min.js', '', true);
    wp_enqueue_script('validation.min.js', MY_DOC_PLUGIN_URL . '/assets/js/jquery.validate.min.js', '', true);
    wp_enqueue_script('datatable.min.js', MY_DOC_PLUGIN_URL . '/assets/js/jquery.dataTables.min.js', '', true);
    wp_enqueue_script('jquery.notifyBar.js', MY_DOC_PLUGIN_URL . '/assets/js/jquery.notifyBar.js', '', true);
    wp_enqueue_script('script.js', MY_DOC_PLUGIN_URL . '/assets/js/script.js', '', true);
    wp_enqueue_script('script.js', MY_DOC_PLUGIN_URL . '/assets/js/bootstrap.min.js', '', true);
}
add_action("init", "my_DOC_include_assets");

// Register activation hook
register_activation_hook(__FILE__, 'docro_myplugin_create_table');

function docro_myplugin_create_table()
{
    // Get global $wpdb object
    global $wpdb;

    // Set table name and create SQL query
    $table_name = $wpdb->prefix . 'docro';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $sql = "CREATE TABLE $table_name (
         id INT(11) NOT NULL AUTO_INCREMENT,
         name VARCHAR(50) NOT NULL,
         documnets VARCHAR(255),
         PRIMARY KEY (id)
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    }
    // Execute query and check for errors
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // user registratio query 
    $table_name2 = $wpdb->prefix . 'docro_user_table';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name2'") != $table_name2) {
        $sql2 = "CREATE TABLE $table_name2(
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(30) NOT NULL,
        email VARCHAR(50),
        phone VARCHAR(20),
        resume VARCHAR(100),
        experience_letter VARCHAR(100),
        salary_slip VARCHAR(100),
        covid_vaccine_certificate VARCHAR(100),
        itr_bank_statement VARCHAR(100),
        ielts_trf_copy VARCHAR(100),
        canada_certification VARCHAR(100),
        educational_documents VARCHAR(100),
        medical_test VARCHAR(100),
        reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        dbDelta($sql2);
    }
}
// addning on menu
// adding menu
add_action("admin_menu", "add_docro_custom_menu");
function add_docro_custom_menu()
{
    add_menu_page(
        "Docro",
        "Docs",
        "manage_options",
        "docs",
        "docro_form",
        "dashicons-index-card",
        6
    );
    add_submenu_page(
        "docs",
        " doc usertable",
        "doc User table",
        "manage_options",
        __FILE__,
        "docro_table"
    );
}

function docro_form()
{
    echo "<h3>Use this shortcode for form [docro_my_plugin_form]</h3><br>";
}

function docro_table()
{
    include plugin_dir_path(__FILE__) . 'table.php';
}




include plugin_dir_path(__FILE__) . 'form.php';

