<?php
require_once(ABSPATH . 'wp-includes/pluggable.php');
function docro_my_plugin_form_shortcode()
{
?>
    <div class="container bg-light shadow my-3 p-3  rounded">
        <form method="post" enctype="multipart/form-data">
            <div class="form-row ">
                <div class="form-gorup col-md-6">
                    <label for="name">Name:</label>
                    <input class="form-control" type="text" name="name" id="name" required>
                </div>
                <div class="form-gorup col-md-6">
                    <label for="email">Email:</label>
                    <input class="form-control" type="email" name="email" id="email" required>
                </div>
            </div>
            <div class="form-row ">
                <div class="form-gorup col-md-6">
                    <label for="phone">Mobile Number:</label>
                    <input class="form-control" type="tel" name="phone" id="phone" required>
                </div>
                <div class="form-gorup col-md-6">
                    <label for="resume">Resume:</label>
                    <input class="form-control" type="file" name="resume" id="resume" accept=".pdf,.doc,.docx">
                </div>
            </div>
            <div class="form-row ">
                <div class="form-gorup col-md-6">
                    <label for="experience_letter">Experience Letter:</label>
                    <input class="form-control" type="file" name="experience_letter" id="experience_letter" accept=".pdf,.doc,.docx">
                </div>
                <div class="form-gorup col-md-6">
                    <label for="salary_slip">Salary Slip:</label>
                    <input class="form-control" type="file" name="salary_slip" id="salary_slip" accept=".pdf,.doc,.docx">
                </div>
            </div>
            <div class="form-row ">
                <div class="form-gorup col-md-6">
                    <label for="covid_vaccine_certificate">COVID Vaccine Certificate:</label>
                    <input class="form-control" type="file" name="covid_vaccine_certificate" id="covid_vaccine_certificate" accept=".pdf,.jpg,.jpeg,.png">
                </div>
                <div class="form-gorup col-md-6">
                    <label for="itr_bank_statement">ITR / Bank Statement (Showing Salary):</label>
                    <input class="form-control" type="file" name="itr_bank_statement" id="itr_bank_statement" accept=".pdf,.doc,.docx">
                </div>
            </div>
            <div class="form-row ">
                <div class="form-gorup col-md-6">
                    <label for="ielts_trf_copy">IELTS TRF Copy:</label>
                    <input class="form-control" type="file" name="ielts_trf_copy" id="ielts_trf_copy" accept=".pdf,.jpg,.jpeg,.png">

                </div>
                <div class="form-gorup col-md-6">
                    <label for="canada_certification">Certification in Canada (if available):</label>
                    <input class="form-control" type="file" name="canada_certification" id="canada_certification" accept=".pdf,.jpg,.jpeg,.png">

                </div>
            </div>

            <div class="form-row ">
                <div class="form-gorup col-md-6">
                    <label for="educational_documents">Educational Documents:</label>
                    <input class="form-control" type="file" name="educational_documents" id="educational_documents" accept=".pdf,.doc,.docx">
                </div>
                <div class="form-gorup col-md-6">

                    <label for="medical_test">Medical Test by Panel Physicians:</label>
                    <input class="form-control" type="file" name="medical_test" id="medical_test" accept=".pdf,.jpg,.jpeg,.png">
                </div>
            </div>

            <input class="form-control btn pb-5" type="submit" name="usubmit" value="Submit">
        </form>
    </div>


<?php
}
add_shortcode('docro_my_plugin_form', 'docro_my_plugin_form_shortcode');

global $wpdb;
$table_name = $wpdb->prefix . 'docro_user_table'; // replace job_applications with your desired table name

if (isset($_POST['usubmit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $resume = $_FILES['resume']['name'];
    $experience_letter = $_FILES['experience_letter']['name'];
    $salary_slip = $_FILES['salary_slip']['name'];
    $covid_vaccine_certificate = $_FILES['covid_vaccine_certificate']['name'];
    $itr_bank_statement = $_FILES['itr_bank_statement']['name'];
    $ielts_trf_copy = $_FILES['ielts_trf_copy']['name'];
    $canada_certification = $_FILES['canada_certification']['name'];
    $educational_documents = $_FILES['educational_documents']['name'];
    $medical_test = $_FILES['medical_test']['name'];


    $upload_dir = wp_upload_dir(); // get WordPress uploads directory information

    $resume_path = $upload_dir['basedir'] . "/" . $resume;
    if ($_FILES['resume']['error'] === UPLOAD_ERR_OK) {
        move_uploaded_file($_FILES['resume']['tmp_name'], $resume_path);
    }

    $experience_letter_path = $upload_dir['basedir'] . "/" . $experience_letter;
    if ($_FILES['experience_letter']['error'] === UPLOAD_ERR_OK) {
        move_uploaded_file($_FILES['experience_letter']['tmp_name'], $experience_letter_path);
    }

    $salary_slip_path = $upload_dir['basedir'] . "/" . $salary_slip;
    if ($_FILES['salary_slip']['error'] === UPLOAD_ERR_OK) {
        move_uploaded_file($_FILES['salary_slip']['tmp_name'], $salary_slip_path);
    }

    $covid_vaccine_certificate_path = $upload_dir['basedir'] . "/" . $covid_vaccine_certificate;
    if ($_FILES['covid_vaccine_certificate']['error'] === UPLOAD_ERR_OK) {
        move_uploaded_file($_FILES['covid_vaccine_certificate']['tmp_name'], $covid_vaccine_certificate_path);
    }
    $itr_bank_statement_path = $upload_dir['basedir'] . "/" . $itr_bank_statement;
    if ($_FILES['itr_bank_statement']['error'] === UPLOAD_ERR_OK) {
        move_uploaded_file($_FILES['itr_bank_statement']['tmp_name'], $itr_bank_statement_path);
    }
    $canada_certification_path = $upload_dir['basedir'] . "/" . $canada_certification;
    if ($_FILES['canada_certification']['error'] === UPLOAD_ERR_OK) {
        move_uploaded_file($_FILES['canada_certification']['tmp_name'], $canada_certification_path);
    }
    $educational_documents_path = $upload_dir['basedir'] . "/" . $educational_documents;
    if ($_FILES['educational_documents']['error'] === UPLOAD_ERR_OK) {
        move_uploaded_file($_FILES['educational_documents']['tmp_name'], $educational_documents_path);
    }
    $medical_test_path = $upload_dir['basedir'] . "/" . $medical_test;
    if ($_FILES['medical_test']['error'] === UPLOAD_ERR_OK) {
        move_uploaded_file($_FILES['medical_test']['tmp_name'], $medical_test_path);
    }


    $data = array(
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'resume' => $resume,
        'experience_letter' => $experience_letter,
        'salary_slip' => $salary_slip,
        'covid_vaccine_certificate' => $covid_vaccine_certificate,
        'itr_bank_statement' => $itr_bank_statement,
        'ielts_trf_copy' => $ielts_trf_copy,
        'canada_certification' => $canada_certification,
        'educational_documents' => $educational_documents,
        'medical_test' => $medical_test
    );
    $wpdb->insert($table_name, $data);
    // Redirect to the same page after submitting the form
    $current_url = esc_url_raw($_SERVER['REQUEST_URI']);
    wp_safe_redirect($current_url);
    exit;
}

?>