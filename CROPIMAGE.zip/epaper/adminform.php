<form enctype="multipart/form-data" method="post" style="margin-top: 300px;">
    <label for="paper_title">Paper Title</label>
    <input type="text" name="paper_title" id="paper_title" required>
    <br>
    <label for="paper_file">Paper File</label>
    <input type="file" accept=".jpg, .jpeg, .png, .pdf" name="paper_file" id="paper_file" required>
    <br>
    <input type="submit" name="cpsubmit" value="Submit">
</form>

<?php
// Add the following code to the same file or in your plugin or theme's functions.php file to handle form submission and insert data into the database

global $wpdb; // Include the global wpdb object

if (isset($_POST['cpsubmit'])) {
    $paper_title = sanitize_text_field($_POST['paper_title']); // Sanitize and get the paper title
    $paper_file = $_FILES['paper_file']; // Get the uploaded file data
    $file_name = sanitize_file_name($paper_file['name']);

    $paper_file_path = '';
    if ($paper_file['name']) {
        $upload_dir = wp_upload_dir();
        $paper_file_name = basename($paper_file['name']);
        $paper_file_path = $upload_dir['url'] . '/' . $paper_file_name;
        move_uploaded_file($paper_file['tmp_name'], $upload_dir['path'] . '/' . $paper_file_name);
    }

    $wpdb->insert($wpdb->prefix . 'crop_epaper', array(
        'paper_title' => $paper_title,
        'paper_file' => $paper_file_path,
        ));

    if ($wpdb->insert_id) {
        echo 'Paper data inserted successfully!';
    } else {
        echo 'Failed to insert paper data.';
    }
} 

?>