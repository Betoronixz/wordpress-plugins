<?php
/*
 * Plugin Name:       epaper crop
 * Author:            Traffic Tail
 * Author URI:        https://traffictail.com/
 * Plugin URI:        https://traffictail.com/
 */


 if (!defined("ABSPATH")) {
    die("can't access");
}
// including stylesheet and javascript
function enqueue_custom_stylesheet() {
    // Enqueue your custom stylesheet
    wp_enqueue_style( 'custom-style', plugin_dir_url( __FILE__ ) . 'assets/style.css' );
    wp_enqueue_style( 'boost-style', plugin_dir_url( __FILE__ ) . 'assets/bootstrap.min.css' );
    wp_enqueue_style( 'cropper-style', plugin_dir_url( __FILE__ ) . 'assets/cropper.min.css' );

    // js scriptsd
    wp_enqueue_script( 'jquery' );

    wp_enqueue_script( 'custom-script', plugin_dir_url( __FILE__ ) . 'assets/script.js', array(), '1.0', true );
    wp_enqueue_script( 'croper-script', plugin_dir_url( __FILE__ ) . 'assets/cropper.min.js', array(), '1.0', true );
    wp_enqueue_script( 'boost-script', plugin_dir_url( __FILE__ ) . 'assets/bootstrap.min.js', array(), '1.0', true );
    wp_enqueue_script( 'jq-script', plugin_dir_url( __FILE__ ) . 'assets/jquery-3.5.1.min.js', array(), '1.0', true );

}
add_action( 'wp_enqueue_scripts', 'enqueue_custom_stylesheet' );


// Register activation hook
register_activation_hook(__FILE__, 'epaper_create_table');

function epaper_create_table()
{
    // Get global $wpdb object
    global $wpdb;

    // Set table name and create SQL query
    $table_name = $wpdb->prefix . 'crop_epaper';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $sql = "CREATE TABLE $table_name (
            paper_title VARCHAR(255),
            paper_id INT(11) AUTO_INCREMENT PRIMARY KEY,
            paper_file BLOB
        );
        ";
    }
    // Execute query and check for errors
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

   
}
// adding on menu
add_action("admin_menu", "add_ep_custom_menu");
function add_ep_custom_menu()
{
    add_menu_page(
        "ep-form",
        "E paper form",
        "manage_options",
        "ep-form",
        "epform",
        "dashicons-index-card",
        6
    );
   
}
function epform(){
    
    include plugin_dir_path(__FILE__) ."adminform.php";
   
}


include plugin_dir_path(__FILE__) ."epd.php";
?>
