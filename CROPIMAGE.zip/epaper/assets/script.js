var bs_modal = jQuery('#modal');
var image = document.getElementById('image');
var cropper, reader;

// Function to display image in modal
function showImageInModal(url) {
    image.src = url;
    bs_modal.modal('show');
}

// Event listener for image click
jQuery("body").on("click", ".image", function(e) {
    var imageUrl = jQuery(this).attr('src');
    showImageInModal(imageUrl);
});

// Event listener for shown.bs.modal event
bs_modal.on('shown.bs.modal', function() {
    cropper = new Cropper(image, {
        aspectRatio: NaN, // Set aspect ratio to 2:1 for rectangle
        viewMode: 3,
        preview: '.preview'
    });
}).on('hidden.bs.modal', function() {
    cropper.destroy();
    cropper = null;
});

// Event listener for crop button click
jQuery("#crop").click(function() {
    canvas = cropper.getCroppedCanvas({
        width: 160,
        height: 80, // Set desired height for the cropped image
    });

    canvas.toBlob(function(blob) {
        var link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'cropped_part.jpg'; // Set desired download filename
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
        bs_modal.modal('hide');
    }, 'image/jpeg', 0.8);
});
