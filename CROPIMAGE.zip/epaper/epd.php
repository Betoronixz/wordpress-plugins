<?php
add_shortcode("epdisplay", "ep_ds");

function ep_ds()
{
    ob_start();
?>
    <div class="newspaper-section">
        <div class="all-newspapers-container">
            <h2>All Newspapers</h2>
            <?php
global $wpdb;
$table_name = $wpdb->prefix . "crop_epaper";
$result = $wpdb->get_results("SELECT * FROM $table_name");
if (!empty($result)) {
    foreach ($result as $r) {
        $file_url = $r->paper_file;
        $file_extension = pathinfo($file_url, PATHINFO_EXTENSION);
        ?>
        <div class="newspaper-item">
            <?php if ($file_extension == 'jpg' || $file_extension == 'jpeg' || $file_extension == 'png' || $file_extension == 'gif') { ?>
                <img src="<?php echo $file_url; ?>" alt="Image" class="image">
            <?php } elseif ($file_extension == 'pdf') { ?>
                <embed src="<?php echo $file_url; ?>" type="application/pdf" class="pdf" width="100%" height="400px" />
            <?php } else { ?>
                <p>File format not supported</p>
            <?php } ?>
        </div>
        <?php
    }
}
?>

            <!-- Add more newspaper items here -->
        </div>
        
       
    </div>

    <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel">Crop image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="img-container">
                        <div class="row">
                            <div class="col-md-8">
                                <!--  default image where we will set the src via jquery-->
                                <img id="image">
                            </div>
                            <div class="col-md-4">
                                <div class="preview"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="crop">Download</button>
                </div>
            </div>
        </div>
    </div>

<?php
    return ob_get_clean();
}
?>