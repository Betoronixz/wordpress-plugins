<?php
/*Plugin Name: School Management System
Description: 
Version: 1.0
Author: Traffic Tail
*/
if (!defined("ABSPATH")) {
    die("can't access");
}

register_activation_hook(__FILE__, 'tt_scm_create_table');
function tt_scm_create_table()
{
    // Get global $wpdb object
    global $wpdb;

    // Set table name and create SQL query
    $table_name = $wpdb->prefix . 'tt_school_registration';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $sql = "CREATE TABLE $table_name (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL,
            status VARCHAR(255) NOT NULL,
            registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
          );
          ";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    $table_name2 = $wpdb->prefix . 'tt_student_enrollment';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name2'") != $table_name2) {
        $sql2 = "CREATE TABLE IF NOT EXISTS $table_name2 (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                age INT NOT NULL,
                school_name VARCHAR(100) NOT NULL,
                grade INT NOT NULL
                );";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql2);
    }

    // Creating Page '
    $page_title = 'Student Data';
    $shortcode = '[student_data]'; // Replace with your actual shortcode
    $page = array(
        'post_title'    => $page_title,
        'post_content'  => $shortcode,
        'post_status'   => 'publish',
        'post_author'   => 1,
        'post_type'     => 'page',
        'page-slug'    => 'student-data'
    );
    $page_id = wp_insert_post($page);
}

// adding on menu
add_action("admin_menu", "scm_custom_menu");
function scm_custom_menu()
{
    add_menu_page(
        "SCM",
        "TT-SCM",
        "manage_options",
        "tt-scm",
        "scmdash",
        "dashicons-index-card",
        6
    );
    add_submenu_page(
        "tt-scm",
        "Studente-data",
        "Student Data",
        "manage_options",
        "scm-data",
        "scmdata"
    );
}


function scmdata()
{
    include plugin_dir_path(__FILE__) . "/admin/scmdata.php";
}

function scmdash()
{
    include plugin_dir_path(__FILE__) . "/admin/admindashboard.php";
}

add_action('admin_enqueue_scripts', 'tt_scm_admin_script');
function tt_scm_admin_script()
{
    if (isset($_GET['page']) && ($_GET['page'] == 'tt-scm' || $_GET['page'] == 'scm-data')) {
        wp_enqueue_style('custom-scmstyle', plugin_dir_url(__FILE__) . 'assets/style.css');
    }
}

add_action('init', 'tt_scm_all_script');
function tt_scm_all_script()
{
    wp_enqueue_script('jquery');
    wp_enqueue_script("bstjs", "https://code.jquery.com/jquery-3.2.1.slim.min.js");
    wp_enqueue_style('jq-data-css', "//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css");
    wp_enqueue_script('jq-data-js', "//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js");
    wp_enqueue_script('custom-scmsscript', plugin_dir_url(__FILE__) . 'assets/script.js');}

add_action('wp_enqueue_scripts', 'tt_scm_al_script');
function tt_scm_al_script()
{
    wp_enqueue_script('jquery');
    wp_enqueue_script("bstjs", "https://code.jquery.com/jquery-3.2.1.slim.min.js");
    wp_enqueue_script("bstjs2", "https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js ");
    wp_enqueue_script("bstjs3", "https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js");
}





include plugin_dir_path(__FILE__) . "school/schoolform.php";
include plugin_dir_path(__FILE__) . "school/schoollogin.php";
include plugin_dir_path(__FILE__) . "school/studentdata.php";
include plugin_dir_path(__FILE__) . "/studentform.php";
