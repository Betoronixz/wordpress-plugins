<?php
if (!defined("ABSPATH")) {
  die("can't access");
}
add_shortcode('student_form', 'student_form');

function student_form()
{
  ob_start();
?>

  <form action="" method="post">
    <input type="hidden" name="action" value="enrollment_form">
    <label for="student_name">Name:</label>
    <input type="text" name="name" required><br>

    <label for="student_age">Age:</label>
    <input type="number" name="age" required><br>

    <label for="student_grade">Grade:</label>
    <select name="grade" required>
      <option value="">Select Grade</option>
      <option value="1">Grade 1</option>
      <option value="2">Grade 2</option>
      <option value="3">Grade 3</option>
      <!-- Add more grade options as needed -->
    </select><br>

    <label for="school_name">School Name:</label>
    <select name="school_name" required>
      <option value="">Select School</option>

      <?php
      global $wpdb;
      $table_name = $wpdb->prefix . "tt_school_registration ";
      $result = $wpdb->get_results("SELECT * FROM $table_name WHERE status='approved'");
      if (!empty($result)) {
        foreach ($result as $r) {
      ?>
          <option value="<?php echo $r->name ?>"><?php echo $r->name ?></option>
        <?php } }?>
    </select>

    <input type="submit" name="st_submit" value="Enroll">
  </form>


<?php
        return ob_get_clean();
      
    }
    if (isset($_POST['st_submit'])) {
      global $wpdb;
  
      // Get the form data
      $name = $_POST['name'];
      $age = $_POST['age'];
      $grade = $_POST['grade'];
      $school_name = $_POST['school_name'];
  
      // Prepare the data for insertion
      $data = array(
          'name' => $name,
          'age' => $age,
          'grade' => $grade,
          'school_name' => $school_name,
      );
  
      // Table name
      $table_name = $wpdb->prefix . 'tt_student_enrollment'; // Replace 'enrollment' with your table name
  
      // Insert the data into the table
      $wpdb->insert($table_name, $data);
  }
  
?>