<?php
if (!defined("ABSPATH")) {
    die("can't access");
}
add_shortcode('student_data', 'st_data');

function st_data()
{
    ob_start();
?>
    <div class="sctable">
        <?php if (isset($_SESSION['school_name'])) {?>
    <form method="post">
        <button type="submit" name="logout_submit">Logout</button>
    </form>
    <?php
        }
if (isset($_POST['logout_submit'])) {
    session_start();
    session_destroy();
    wp_redirect(home_url('/')); // Redirect to the home page or any other desired page after logout
    exit;
}
?>
        <table id="table_id2">
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Age</th>
                    <th>Grade</th>
                </tr>
            </thead>
            <tbody>
                <?php
                global $wpdb;
                $table_name = $wpdb->prefix . "tt_student_enrollment";
                $school_name = $_SESSION['school_name'];
                $result = $wpdb->get_results("SELECT * FROM $table_name WHERE school_name = '$school_name'");
                if (!empty($result)) {
                    foreach ($result as $r) {
                ?>
                        <tr>
                            <td><?php echo $r->name ?></td>
                            <td><?php echo $r->age ?></td>
                            <td><?php echo $r->grade; ?></td>

                        </tr>
                <?php }
                }
                if (isset($_POST['submit_status'])) {
                    global $wpdb;
                    $table_name = $wpdb->prefix . "tt_school_registration";
                    $id = $_POST['id'];
                    $new_status = $_POST['status'];

                    $user_data = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $id");
                    // Update the status in the database
                    $wpdb->update(
                        $table_name,
                        array('status' => $new_status),
                        array('id' => $id)
                    );
                }
                ?>

            </tbody>
        </table>
    </div>

<?php
    return ob_get_clean();
}
?>