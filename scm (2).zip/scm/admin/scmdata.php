<div id="wrapper">
    <nav class="navbar navbar-inverse fixed-top" id="sidebar-wrapper" role="navigation">
        <ul class="nav sidebar-nav">
            <div class="sidebar-header">
                <div class="sidebar-brand">
                    <a href="https://traffictail.com/"><img src="https://traffictail.com/wp-content/uploads/2022/10/tt-logo.png" width="200px" alt="" srcset=""></a>
                </div>
            </div>
            <li><a href="<?php echo home_url().'/wp-admin/admin.php?page=tt-scm';?>">School </a></li>
            <li><a href="<?php echo home_url().'/wp-admin/admin.php?page=scm-data'?>">Complete Data</a></li>
    </nav>
</div>
<!-- /#wrapper -->
<div class="sctable">
<table id="table_id">
    <thead>
        <tr>
            <th>School Name</th>
            <th>Student Name</th>
            <th>age</th>
            <th>grade</th>
        </tr>
    </thead>
    <tbody>
    <?php
            global $wpdb;
            $table_name = $wpdb->prefix . "tt_student_enrollment";
            $result = $wpdb->get_results("SELECT * FROM $table_name");
            if (!empty($result)) {
              foreach ($result as $r) {
            ?>
        <tr>
            <td><?php echo $r->school_name?></td>
            <td><?php echo $r->name?></td>
            <td><?php echo $r->age ?></td>
            <td><?php echo $r->grade ?></td>
        </tr>
        <?php }}
        if (isset($_POST['submit_status'])) {
            global $wpdb;
            $table_name = $wpdb->prefix . "tt_school_registration";
            $id = $_POST['id'];
            $new_status = $_POST['status'];
          
            $user_data = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $id");
            // Update the status in the database
            $wpdb->update(
              $table_name,
              array('status' => $new_status),
              array('id' => $id)
            );
            echo "<script>location.reload(true)</script>"   ;      
        }
        ?>
        
    </tbody>
</table>
</div>