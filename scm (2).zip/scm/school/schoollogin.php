<?php
if (!defined("ABSPATH")) {
    die("can't access");
}
add_shortcode('scs_login', 'scs_log');

function scs_log()
{
    ob_start();
?>
    <h1>School Login</h1>
    <form action="" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>

        <input type="submit" name="login_submit" value="Login">
    </form>
<?php
    return ob_get_clean();
}
if (isset($_POST['login_submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Custom table name
    $table_name = $wpdb->prefix . 'tt_school_registration'; // Replace 'tt_school_registration' with your custom table name

    // Check if the user exists in the custom table with status "approved"
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE email = %s AND status = 'approved'", $email));

    if ($user) {
        // Verify the password
        if (wp_check_password($password, $user->password)) {
            // Password is correct, login successful
            // Start a session and store the school name
            session_start();
            $_SESSION['school_name'] = $user->name; // Assuming 'school_name' is the field name in the table

            // Redirect to student-data page
            wp_redirect(home_url('/student-data'));
            exit;
        } else {
            // Password is incorrect
            $login_status = 'Login Failed: Incorrect password.';
        }
    } else {
        // User does not exist or is not approved
        $login_status = 'Login Failed: User not found or not approved.';
    }

    // Display login status message
    echo $login_status;

    // Output JavaScript code to display alert
    echo "<script>alert('" . $_SESSION['school_name'] . "');</script>";
}

