<?php
if (!defined("ABSPATH")) {
    die("can't access");
}
add_shortcode('school_form', 'schoolr_form');

function schoolr_form()
{
    ob_start();
?>

    <h2>School Registration Form</h2>
    <form action="" method="post">
        <div class="form-group col-md-6 ">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="form-group col-md-6 ">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group col-md-6 ">
            <label for="grade">Passowrd:</label>
            <input type="password" name="passowrd" class="form-control" required>

        </div>

        <input type="submit" name="scsubmit" value="Submit">
    </form>
<?php
    return ob_get_clean();
}
if (isset($_POST['scsubmit'])) {
    global $wpdb;

    // Get the form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['passowrd'];

    // Hash the password
    $hashed_password = wp_hash_password($password);

    // Prepare the data for insertion
    $data = array(
        'name' => $name,
        'email' => $email,
        'password' => $hashed_password,
        'status' => "pending"
    );

    // Table name
    $table_name = $wpdb->prefix . 'tt_school_registration'; // Replace 'tt_school_registration' with your table name

    // Insert the data into the table
    $result = $wpdb->insert($table_name, $data);

    if ($result) {
        // Form submission successful
        echo 'Form submitted successfully!';
    } else {
        // Form submission failed
        echo 'Form submission failed.';
    }
}


?>